#ifndef __BSP_PIT_H
#define __BSP_PIT_H

#include "fsl_common.h"
#include "fsl_pit.h"
#include "fsl_clock.h"


#define PIT_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_OscClk)


void PIT_Configuration(void);

#endif /* __BSP_PIT_H */

