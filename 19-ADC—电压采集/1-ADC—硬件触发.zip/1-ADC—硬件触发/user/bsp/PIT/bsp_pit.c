#include "./pit/bsp_pit.h"



/*!
* @brief Configuration PIT to trigger ADC_ETC.
*        ����PIT ����ADC_ETC
*/
void PIT_Configuration(void)
{
    /* Structure of initialize PIT */
    pit_config_t pitConfig;

    /* Init pit module */
    PIT_GetDefaultConfig(&pitConfig);
    PIT_Init(PIT, &pitConfig);

    /* Set timer period for channel 0 Ϊtimer ���ü�������*/
    PIT_SetTimerPeriod(PIT, kPIT_Chnl_0, USEC_TO_COUNT(1000000U, PIT_SOURCE_CLOCK));
}